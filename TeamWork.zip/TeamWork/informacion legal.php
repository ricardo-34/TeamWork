<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Términos y Condiciones - TeamWord</title>
    <link rel="stylesheet" href="CSS/informacion legal.css">
</head>
<body>

    <div class="container">
        <header>
            <h1>Términos y Condiciones</h1>
            <p>Última actualización: <strong>[Fecha]</strong></p>
        </header>

        <section class="terms-content">
            <h2>1. Aceptación de los Términos</h2>
            <p>Al utilizar <strong>TeamWord</strong>, aceptas los siguientes términos y condiciones de uso. Si no estás de acuerdo con alguno de estos términos, te recomendamos no utilizar la plataforma.</p>

            <h2>2. Descripción del Servicio</h2>
            <p><strong>TeamWord</strong> es una plataforma de colaboración en línea diseñada para facilitar la creación y gestión de proyectos grupales.</p>

            <h2>3. Registro de Usuario</h2>
            <p>Para acceder a <strong>TeamWord</strong>, debes registrarte creando una cuenta. Es tu responsabilidad proporcionar información precisa.</p>

            <h2>4. Responsabilidad del Usuario</h2>
            <p>Al utilizar la plataforma, aceptas las siguientes responsabilidades...</p>

            <h2>5. Uso Aceptable</h2>
            <p>Se prohíbe utilizar la plataforma para actividades que puedan dañar a otros usuarios o el servicio.</p>

            <h2>6. Propiedad Intelectual</h2>
            <p>Todo el contenido y software de <strong>TeamWord</strong> está protegido por derechos de autor.</p>

            <h2>7. Limitación de Responsabilidad</h2>
            <p><strong>TeamWord</strong> no será responsable por daños o pérdidas derivados del uso incorrecto de la plataforma.</p>

            <h2>8. Suspensión o Terminación del Servicio</h2>
            <p>Podemos suspender o terminar tu acceso si incumples estos términos.</p>

            <h2>9. Política de Reembolsos</h2>
            <p>Los usuarios pueden solicitar un reembolso dentro de los primeros 14 días tras la compra de una suscripción.</p>

            <h2>10. Cambios en los Términos</h2>
            <p>Nos reservamos el derecho a modificar estos términos en cualquier momento. Se notificará a los usuarios de los cambios realizados.</p>

            <h2>11. Ley Aplicable y Jurisdicción</h2>
            <p>Estos términos se regirán de acuerdo con las leyes del país donde TeamWord tenga su sede legal.</p>

            <h2>12. Contacto Legal</h2>
            <p>Si tienes dudas, puedes contactarnos en <strong>legal@teamword.com</strong>.</p>
        </section>

        <footer>
            <p>&copy; 2024 TeamWord. Todos los derechos reservados.</p>
        </footer>
    </div>

</body>
</html>
