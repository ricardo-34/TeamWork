
<?php
session_start();

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    // Si no ha iniciado sesión, redirigir a la página principal
    header("Location: index.php");
    exit();
}

// Si el usuario tiene una sesión activa, mostrar la página de usuario
echo "<h1>Bienvenido, " . htmlspecialchars($_SESSION['usuario']) . "</h1>";
// Aquí puedes agregar más funcionalidades, como mostrar información adicional del usuario
?>



<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Página de Usuario</title>
    <link rel="stylesheet" href="CSS/styles.user.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>
    <!-- Header -->
    <header class="header-style">
        <div class="logo-style">
            <img src="IMG/Logo.png" alt="Logo de la Página">
        </div>
        <div class="header-icons-style">
            <div class="notification-icon-style" id="notification-icon">
                <i class="fas fa-bell"></i>
                <div class="notification-dropdown-style" id="notification-dropdown">
                    <div class="notification-header-style">
                        <h1>Notificaciones</h1>
                    </div>
                    <div class="notification-item-style">
                        <!-- Aquí irían las notificaciones -->
                    </div>
                    <div class="notification-footer-style">
                        <a href="#">Ver todo</a>
                    </div>
                </div>
            </div>
            <div class="profile-icon-style" id="profile-icon">
                <i class="fas fa-user-circle"></i>
                <div class="profile-dropdown-style" id="profile-dropdown">
                    <div class="profile-header-style">
                        <span><?php echo $_SESSION['usuario']; ?></span>
                    </div>
                    <ul class="profile-menu-style">
                        <li><a id="perfil-button" href="#">Perfil</a></li>
                        <li><a id="settings-button" href="#">Configuración</a></li>
                        <li><a href="php/logout.php" class="logout-button">Cerrar sesión</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <!-- Menú Lateral -->
    <aside class="sidebar-style">
        <div class="toggle-menu" id="toggle-menu">
            <i class="fas fa-bars"></i>
        </div>
        <ul class="menu-style" id="menu-list">
            <li><a href="#" id="projects-button"><i class="fas fa-folder"></i> <span>Proyectos</span></a></li>
            <li><a href="#" id="messages-button"><i class="fas fa-comments"></i> <span>Mensajes</span></a></li>
            <li><a href="#" id="calendar-button"><i class="fas fa-calendar"></i> <span>Calendario</span></a></li>

        </ul>
    </aside>

    <!-- Contenido Principal -->
    <main class="main-content-style">
        <div class="view-section-style active" id="projects-view">
            <div class="titulo-buton">
                <h1>Proyectos</h1>
                <button id="create-project-button" class="create-project-button">Crear Proyecto</button>
            </div>
            <div id="projects-list"></div>
        </div>

        <div class="view-section-style" id="profile-view">
            <h1>Editar Perfil</h1>
            <div class="profile">
                <div class="profile-left">
                    <div class="profile-picture">
                        <img src="" alt="Foto de Perfil" id="profileImage">
                        <label for="imageUpload" class="upload-btn">Subir Imagen</label>
                        <input type="file" id="imageUpload" accept="image/*">
                    </div>
                    <button id="editBtn">Editar Perfil</button>
                    <button id="saveBtn" style="display: none;">Guardar Cambios</button>
                </div>

                <div class="profile-right">
                    <div class="info-section">
                        <h2>Información Personal</h2>
                        <div class="info-item">
                            <label for="name">Nombre: </label>
                            <input type="text" id="name" value="<?php echo $_SESSION['usuario']; ?>" disabled>
                        </div>
                        <div class="info-item">
                            <label for="email">Correo: </label>
                            <input type="email" id="email" value="<?php echo $_SESSION['email']; ?>" disabled>
                        </div>
                        <div class="info-item">
                            <label for="phone">Teléfono: </label>
                            <input type="text" id="phone" value="" disabled>
                        </div>
                        <div class="info-item">
                            <label for="address">Dirección: </label>
                            <input type="text" id="address" value="" disabled>
                        </div>
                        <div class="info-item">
                            <label for="dob">Fecha de Nacimiento: </label>
                            <input type="date" id="dob" value="" disabled>
                        </div>
                    </div>

                    <div class="info-section">
                        <h2>Redes Sociales</h2>
                        <div class="info-item">
                            <label for="twitter">Instagram: </label>
                            <input type="text" id="twitter" value="" disabled>
                        </div>
                        <div class="info-item">
                            <label for="linkedin">LinkedIn: </label>
                            <input type="text" id="linkedin" value="" disabled>
                        </div>
                    </div>

                    <div class="info-section">
                        <h2>Información Adicional</h2>
                        <div class="info-item">
                            <label for="occupation">Ocupación: </label>
                            <input type="text" id="occupation" value="" disabled>
                        </div>
                        <div class="info-item">
                            <label for="hobbies">Hobbies: </label>
                            <textarea id="hobbies" rows="3" disabled></textarea>
                        </div>
                        <div class="info-item">
                            <label for="preferences">Preferencias: </label>
                            <textarea id="preferences" rows="3" disabled></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="view-section-style" id="settings-view">
            <h1>Configuración</h1>
        </div>

        <div class="view-section-style" id="messages-view">
            <h1>Mensajes de Grupo</h1>
        </div>

        <div class="view-section-style" id="calendar-view">
            <div class="calendario">

                <div class="agenda-container">
                    <div class="agenda-header">
                        <button class="prev-button">&lt;</button>
                        <h2 class="month-year">September 2024</h2>
                        <button class="next-button">&gt;</button>
                    </div>
                    <div class="days-of-week">
                        <div>Lunes</div>
                        <div>Martes</div>
                        <div>Miércoles</div>
                        <div>Jueves</div>
                        <div>Viernes</div>
                        <div>Sábado</div>
                        <div>Domingo</div>
                    </div>
                    <div class="calendar-grid">
                        <!-- Días del mes serán generados dinámicamente por JavaScript -->
                    </div>
                </div>
            </div>
        </div>


        <!-- Modal de Creación de Proyecto -->
        <div id="create-project-modal" class="modal">
            <div class="modal-content">
                <span class="close-btn">&times;</span>
                <span id="prev-step" class="nav-btn">&#9664;</span>

                <!-- Paso 1: Configuración del Proyecto -->
                <div id="step-1" class="modal-step">
                    <h2>Configuración del Proyecto</h2>
                    <form id="project-config-form">
                        <label for="project-name">Nombre del Proyecto:</label>
                        <input type="text" id="project-name" name="projecto-name" required>

                        <label for="project-description">Descripción:</label>
                        <textarea id="project-description" name="project-description" rows="4" required></textarea>

                        <label for="project-status">Estado del Proyecto:</label>
                        <select id="project-status" name="project-status" required>
                            <option value="active">Activo</option>
                            <option value="inactive">Inactivo</option>
                            <option value="completed">Completado</option>
                        </select>
                        <label for="project-deadline">Fecha Límite:</label>
                        <input type="date" id="project-deadline">

                        <button type="button" id="next-to-permissions">Siguiente</button>
                    </form>
                </div>

                <!-- Paso 2: Permisos -->
                <div id="step-2" class="modal-step" style="display: none;">
                    <h2>Permisos</h2>
                    <form id="permissions-form">
                        <label for="user-role">Rol del Usuario:</label>
                        <select id="user-role" name="user-role" required>
                            <option value="admin">Administrador</option>
                            <option value="editor">Editor</option>
                            <option value="viewer">Visualizador</option>
                        </select>

                        <label for="access-level">Nivel de Acceso:</label>
                        <select id="access-level" name="access-level" required>
                            <option value="full">Completo</option>
                            <option value="limited">Limitado</option>
                        </select>

                        <button type="button" id="next-to-members">Siguiente</button>
                    </form>
                </div>

                <!-- Paso 3: Integrantes -->
                <div id="step-3" class="modal-step" style="display: none;">
                    <h2>Agregar Integrantes</h2>
                    <form id="members-form">
                        <div id="members-list">
                            <!-- Integrante por defecto -->
                            <div class="member-item">
                                <input type="email" placeholder="Correo de Gmail" class="email-input" required>
                                <select class="role-select">
                                    <option value="admin">Administrador</option>
                                    <option value="editor">Editor</option>
                                    <option value="viewer">Visualizador</option>
                                </select>
                            </div>
                        </div>
    
                        <button type="button" id="add-member">+ Agregar Integrante</button>
                        <button type="button" id="save-project">Guardar</button>
                    </form>
                </div>
            </div>
        </div>


        <!-- Hoja del Proyecto -->
        <div class="view-section-style" id="project-details-view" style="display: none;">
           
            <h1 id="project-details-name"></h1>
            <p id="project-details-description"></p>
            <p><strong>Fecha Límite:</strong> <span id="project-details-deadline"></span></p>
        </div>
    </main>


    <script src="JS/script-user.js"></script>
</body>

</html>
