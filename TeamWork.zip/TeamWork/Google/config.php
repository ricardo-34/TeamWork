<?php
// Parámetros de configuración
$client_id = "69038096642-dc40v3gg354igo9l9j2a5er9np97mqm0.apps.googleusercontent.com";
$client_secret = "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";  // Asegúrate de no exponer esto al público
$redirect_uri = "http://localhost/TeamWork/index-user.php";  // Debe coincidir con el registrado en la consola de Google

// Si hay un código de autorización en la URL
if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // Intercambia el código por un Access Token y ID Token
    $token_url = "https://oauth2.googleapis.com/token";
    $params = [
        "code" => $code,
        "client_id" => $client_id,
        "client_secret" => $client_secret,
        "redirect_uri" => $redirect_uri,
        "grant_type" => "authorization_code"
    ];

    // Hace la solicitud a Google
    $curl = curl_init($token_url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);

    // Decodifica la respuesta
    $token_response = json_decode($response, true);

    if (isset($token_response['access_token'])) {
        // Aquí tienes el access_token e id_token, puedes hacer lo que quieras con ellos
        $access_token = $token_response['access_token'];
        $id_token = $token_response['id_token'];

        // Redirigir al usuario a la página de perfil
        header('Location: index-user.php');
        exit();
    } else {
        // Error obteniendo el token
        echo "Error en la autenticación: " . $token_response['error_description'];
    }
} else {
    // Si no se recibió código de autorización
    echo "Código de autorización no recibido.";
}
?>
