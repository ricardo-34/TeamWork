document.addEventListener('DOMContentLoaded', () => {
    const container = document.querySelector('.scrolling-content');
    const container_2 = document.querySelector('.scrolling-contentr')

    const items = Array.from(container.children);
    const items_2 = Array.from(container_2.children);

    // Duplicar los elementos
    items.forEach(item => {
        container.appendChild(item.cloneNode(true));
    });

    items.forEach(item => {
        container_2.appendChild(item.cloneNode(true));
    });

    // Ajustar la altura del contenedor según el contenido
    const totalHeight = container.scrollHeight; // La altura total del contenido
    container.style.height = `${totalHeight}px`;

    const totalHeight_2 = container_2.scrollHeight; // La altura total del contenido
    container_2.style.height = `${totalHeight}px`;
});

//login 
document.addEventListener('DOMContentLoaded', () => {
    const actionButton = document.querySelector('.action-button');
    const modalOverlay = document.querySelector('.modal-overlay');
    const loginModal = document.getElementById('modal-login');
    const registerModal = document.getElementById('modal-register');
    const restablecerContraModal = document.getElementById('modal-olvido-contraseña');
    const closeButtons = document.querySelectorAll('.modal-close-login, .modal-close-register, .modal-back-olvido-contraseña, .modal-close-olvido-contraseña, .modal-back-register');

    actionButton.addEventListener('click', () => {
        modalOverlay.classList.remove('ocultar-modal');
        loginModal.style.display = 'flex';
    });

    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            modalOverlay.classList.add('ocultar-modal');
            loginModal.style.display = 'none';
            registerModal.style.display = 'none';
            restablecerContraModal.style.display = 'none';
        });
    });

    modalOverlay.addEventListener('click', () => {
        modalOverlay.classList.add('ocultar-modal');
        loginModal.style.display = 'none';
        registerModal.style.display = 'none';
        restablecerContraModal.style.display = 'none';
    });

    document.querySelector('.link-create-account').addEventListener('click', () => {
        loginModal.style.display = 'none';
        registerModal.style.display = 'flex';
    });

    document.querySelector('.modal-back-register').addEventListener('click', () => {
        registerModal.style.display = 'none';
        loginModal.style.display = 'flex';
    });

    document.querySelector('.link-forgot-password').addEventListener('click', () => {
        loginModal.style.display = 'none';
        restablecerContraModal.style.display = 'flex';
    });
});



//ver demostracion

document.addEventListener('DOMContentLoaded', () => {
    const showVideoBtn = document.querySelector('.show-video-btn');
    const modalBackground = document.querySelector('.modal-background');
    const videoModal = document.querySelector('.video-modal');
    const modalCloseBtn = document.querySelector('.modal-close-btn');

    showVideoBtn.addEventListener('click', () => {
        modalBackground.classList.remove('hidden-element');
        videoModal.classList.remove('hidden-element');
    });

    modalCloseBtn.addEventListener('click', () => {
        modalBackground.classList.add('hidden-element');
        videoModal.classList.add('hidden-element');
    });

    modalBackground.addEventListener('click', () => {
        modalBackground.classList.add('hidden-element');
        videoModal.classList.add('hidden-element');
    });
});


const eyes = document.querySelectorAll('.eye');
const passwordInp = document.querySelector('#register-password');
const confirmpasswordInp = document.querySelector('#register-confirm-password');
const errorSpn = document.querySelector('#msg-error');
const passwordInplist = [passwordInp, confirmpasswordInp]
const passwordLevels = document.querySelectorAll('.password-leves')
let highSecurity = /(?=.*[A-Z])(?=.*\d)/;


//mostrar contraseña
eyes.forEach(eye => {
    eye.addEventListener('click', () => {
        eyes.forEach(eye2 => {
            eye2.classList.toggle('show');
        });
        if (eyes[1].classList.contains('show')) {
            passwordInp.type = 'password';
            confirmpasswordInp.type = 'password';
        } else {
            passwordInp.type = 'text';
            confirmpasswordInp.type = 'text';
        }
    })

});

//comparar contraseñas
passwordInplist.forEach(inputPassword => {

    inputPassword.addEventListener('input', () => {

        if (passwordInp.value !== confirmpasswordInp.value) {
            errorSpn.textContent = 'Contraseñas no coinciden';
            confirmpasswordInp.style.borderColor = '#ff0000'
        } else {
            errorSpn.textContent = '';
            passwordInp.style.borderColor = '#2eb160'
            confirmpasswordInp.style.borderColor = '#2eb160'
        }

    })
})

//niveles de la contraseña
passwordInp.addEventListener('input', () => {
    if (passwordInp.value.length < 8 && passwordInp.value.length > 0) {
        passwordLevels[0].style.backgroundColor = 'red';
        passwordLevels[1].style.backgroundColor = '#ccc';
        passwordLevels[2].style.backgroundColor = '#ccc';

    } else if (passwordInp.value.length >= 8) {
        passwordLevels[0].style.backgroundColor = 'red';
        passwordLevels[1].style.backgroundColor = 'orange';
        passwordLevels[2].style.backgroundColor = '#ccc';

        if (passwordInp.value.length > 8) {
            passwordLevels[0].style.backgroundColor = '#2eb160';
            passwordLevels[1].style.backgroundColor = '#2eb160';
            passwordLevels[2].style.backgroundColor = '#2eb160';

            if (highSecurity.test(passwordInp.value)) {

            }
        }
    }


})


//login Goolge

document.getElementById('google-login').addEventListener('click', function() {
    const clientId = "69038096642-dc40v3gg354igo9l9j2a5er9np97mqm0.apps.googleusercontent.com";
    const redirectUri = "http://localhost/TeamWork/index-user.php";
    const scope = "https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email";
    const responseType = "code";
    const state = "randomState";  // Genera un valor de estado aleatorio para prevenir ataques CSRF.
    
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=${responseType}&scope=${scope}&state=${state}`;

    window.location.href = authUrl;
});