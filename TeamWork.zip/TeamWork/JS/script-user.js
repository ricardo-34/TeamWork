document.addEventListener('DOMContentLoaded', function () {
    const profileIcon = document.getElementById('profile-icon');
    const profileDropdown = document.getElementById('profile-dropdown');
    const notificationIcon = document.getElementById('notification-icon');
    const notificationDropdown = document.getElementById('notification-dropdown');
    const projectsButton = document.getElementById('projects-button');
    const messagesButton = document.getElementById('messages-button');
    const calendarButton = document.getElementById('calendar-button');
    const settingsButton = document.getElementById('settings-button');
    const perfilButton = document.getElementById('perfil-button');

    const projectsView = document.getElementById('projects-view');
    const messagesView = document.getElementById('messages-view');
    const calendarView = document.getElementById('calendar-view');
    const profileView = document.getElementById('profile-view');
    const settingsView = document.getElementById('settings-view');
    const toggleMenuButton = document.getElementById('toggle-menu');
    const sidebar = document.querySelector('.sidebar-style');
    const mainContent = document.querySelector('.main-content-style');

    const createProjectBtn = document.getElementById('create-project-button');
    const modal = document.getElementById('create-project-modal');
    const closeBtn = document.querySelector('.close-btn');
    const nextToPermissionsBtn = document.getElementById('next-to-permissions');
    const nextToMembersBtn = document.getElementById('next-to-members');
    const submitProjectButton = document.getElementById('save-project');
    const projectsList = document.getElementById('projects-list');
    const projectDetailsView = document.getElementById('project-details-view');
    const backToProjectsButton = document.getElementById('back-to-projects-button');
    const projectNameInput = document.getElementById('project-name');
    const projectDescriptionInput = document.getElementById('project-description');
    const projectDeadlineInput = document.getElementById('project-deadline');
    const projectDetailsName = document.getElementById('project-details-name');
    const memberscorreo = document.getElementById('members');
    const projectDetailsDescription = document.getElementById('project-details-description');
    const projectDetailsDeadline = document.getElementById('project-details-deadline');
    const prevStepBtn = document.getElementById('prev-step');
    const membersList = document.getElementById('members-list');
    const addMemberBtn = document.getElementById('add-member');
    
    const steps = document.querySelectorAll('.modal-step');
    let currentStep = 0;
  
    let deadlines = {}; // Objeto para almacenar las fechas de entrega
  
    function showView(view) {
        projectsView.classList.remove('active');
        messagesView.classList.remove('active');
        calendarView.classList.remove('active');
        profileView.classList.remove('active');
        settingsView.classList.remove('active');
        projectDetailsView.style.display = 'none'; // Ocultar vista de detalles del proyecto
        view.classList.add('active');
    }

    function showModal() {
        modal.style.display = 'block';
        showStep(0); // Always show step 1 when opening the modal
    }

    function closeModal() {
        modal.style.display = 'none';
        resetModal(); // Añadir esta línea
    }

    function showStep(stepIndex) {
        steps.forEach((step, index) => {
            step.style.display = index === stepIndex ? 'block' : 'none';
        });
        currentStep = stepIndex;
        updateNavigationButtons();
    }

    function updateNavigationButtons() {
        prevStepBtn.style.display = currentStep > 0 ? 'inline-block' : 'none';
    }

    function resetModal() {
        showStep(0); // Reinicia al Paso 1
    }

    function addMember() {
        const memberDiv = document.createElement('div');
        memberDiv.classList.add('member-item');
        memberDiv.innerHTML = `
            <input type="email" placeholder="Correo de Gmail" required>
            <select>
                <option value="admin">Administrador</option>
                <option value="editor">Editor</option>
                <option value="viewer">Visualizador</option>
            </select>
        `;
        membersList.appendChild(memberDiv);
    }
    

    createProjectBtn.addEventListener('click', showModal);

    closeBtn.addEventListener('click', closeModal);

    prevStepBtn.addEventListener('click', () => {
        showStep(currentStep - 1);
    });

    nextToPermissionsBtn.addEventListener('click', () => {
        showStep(1);
    });

    nextToMembersBtn.addEventListener('click', () => {
        showStep(2);
    });

    addMemberBtn.addEventListener('click', addMember);


    //
  
    profileIcon.addEventListener('click', function () {
        profileDropdown.style.display = profileDropdown.style.display === 'block' ? 'none' : 'block';
        notificationDropdown.style.display = 'none';
    });
  
    notificationIcon.addEventListener('click', function () {
        notificationDropdown.style.display = notificationDropdown.style.display === 'block' ? 'none' : 'block';
        profileDropdown.style.display = 'none';
    });
  
    projectsButton.addEventListener('click', function () {
        showView(projectsView);
    });
  
    messagesButton.addEventListener('click', function () {
        showView(messagesView);
    });
  
    calendarButton.addEventListener('click', function () {
        showView(calendarView);
    });

    perfilButton.addEventListener('click', function () {
        showView(profileView);
    });
  
    settingsButton.addEventListener('click', function () {
        showView(settingsView);
    });

    toggleMenuButton.addEventListener('click', function () {
        sidebar.classList.toggle('sidebar-collapsed');
        mainContent.classList.toggle('main-content-collapsed');
    });
  

    
    // Verificar la existencia de los elementos necesarios
    if (submitProjectButton && projectNameInput && projectDescriptionInput && projectDeadlineInput && membersList && projectsList && modal) {
        submitProjectButton.addEventListener('click', function () {
            const projectName = projectNameInput.value.trim();
            const projectDescription = projectDescriptionInput.value.trim();
            const projectDeadline = projectDeadlineInput.value.trim();
            const memberItems = membersList.querySelectorAll('.member-item');

            const members = Array.from(memberItems).map(item => {
                const emailInput = item.querySelector('.email-input');
                const roleSelect = item.querySelector('.role-select');
                
                if (emailInput && roleSelect) {
                    return {
                        email: emailInput.value.trim(),
                        role: roleSelect.value
                    };
                } 
            }).filter(member => member && member.email); // Filtra los miembros sin correo

            if (projectName && projectDescription && projectDeadline && members.length > 0) {
                const projectItem = document.createElement('div');
                projectItem.classList.add('project-item');
                projectItem.innerHTML = `
                    <div class="project-title">${projectName}</div>
                    <div class="project-info">
                        <span><strong>Descripción:</strong> ${projectDescription}</span>
                        <span><strong>Fecha Límite:</strong> ${projectDeadline}</span>
                    </div>
                `;
                projectItem.addEventListener('click', function () {
                    projectDetailsName.textContent = projectName;
                    projectDetailsDescription.textContent = projectDescription;
                    projectDetailsDeadline.textContent = projectDeadline;
                    projectsView.classList.remove('active');
                    projectDetailsView.style.display = 'block';
                });

                // Almacenar la fecha de entrega en el objeto deadlines
                const deadlineDate = new Date(projectDeadline);
                const formattedDate = `${deadlineDate.getFullYear()}-${('0' + (deadlineDate.getMonth() + 1)).slice(-2)}-${('0' + deadlineDate.getDate()).slice(-2)}`;
                if (!deadlines[formattedDate]) {
                    deadlines[formattedDate] = [];
                }
                deadlines[formattedDate].push(projectName);

                projectsList.appendChild(projectItem);
                modal.style.display = 'none';
                projectNameInput.value = '';
                projectDescriptionInput.value = '';
                projectDeadlineInput.value = '';
                membersList.innerHTML = ''; // Limpiar la lista de miembros
            } else {
                alert('Por favor, completa todos los campos.');
            }
        });

        document.getElementById('add-member').addEventListener('click', function () {
            const memberItem = document.createElement('div');
            memberItem.classList.add('member-item');
            memberItem.innerHTML = `
                <input type="email" placeholder="Correo de Gmail" class="email-input" required>
                <select class="role-select">
                    <option value="admin">Administrador</option>
                    <option value="editor">Editor</option>
                    <option value="viewer">Visualizador</option>
                </select>
            `;
            membersList.appendChild(memberItem);
        });

        const closeButton = document.querySelector('.close-btn');
        if (closeButton) {
            closeButton.addEventListener('click', function () {
                modal.style.display = 'none';
            });
        } else {
            console.error('Botón de cerrar no encontrado.');
        }

        const navButton = document.querySelector('.nav-btn');
        if (navButton) {
            navButton.addEventListener('click', function () {
                // Lógica para navegar al paso anterior
            });
        } else {
            console.error('Botón de navegación no encontrado.');
        }

        const nextToPermissionsButton = document.getElementById('next-to-permissions');
        if (nextToPermissionsButton) {
            nextToPermissionsButton.addEventListener('click', function () {
                document.getElementById('step-1').style.display = 'none';
                document.getElementById('step-2').style.display = 'block';
            });
        } else {
            console.error('Botón de siguiente a permisos no encontrado.');
        }

        const nextToMembersButton = document.getElementById('next-to-members');
        if (nextToMembersButton) {
            nextToMembersButton.addEventListener('click', function () {
                document.getElementById('step-2').style.display = 'none';
                document.getElementById('step-3').style.display = 'block';
            });
        } else {
            console.error('Botón de siguiente a integrantes no encontrado.');
        }
    } else {
        console.error('Uno o más elementos no están presentes en el DOM.');
    }
    // Calendario
    const monthYearDisplay = document.querySelector('.month-year');
    const calendarGrid = document.querySelector('.calendar-grid');
    const prevButton = document.querySelector('.prev-button');
    const nextButton = document.querySelector('.next-button');
    let currentDate = new Date();
  
    function renderCalendar(date) {
        const year = date.getFullYear();
        const month = date.getMonth();
        monthYearDisplay.textContent = date.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });
        calendarGrid.innerHTML = '';

        const firstDayOfMonth = new Date(year, month, 1).getDay() || 7; // Ajustar para que el lunes sea el primer día
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        // Espacios en blanco para los días antes del primer día del mes
        for (let i = 1; i < firstDayOfMonth; i++) {
            const emptyCell = document.createElement('div');
            calendarGrid.appendChild(emptyCell);
        }

        // Días del mes
        for (let day = 1; day <= daysInMonth; day++) {
            const dayCell = document.createElement('div');
            dayCell.classList.add('day');
            dayCell.textContent = day;

            // Añadir notas de fechas de entrega
            const formattedDate = `${year}-${('0' + (month + 1)).slice(-2)}-${('0' + day).slice(-2)}`;
            if (deadlines[formattedDate]) {
                const note = document.createElement('div');
                note.classList.add('note');
                note.textContent = `${deadlines[formattedDate].join(', ')}`;
                dayCell.appendChild(note);
            }

            calendarGrid.appendChild(dayCell);
        }
    }

    function changeMonth(delta) {
        currentDate.setMonth(currentDate.getMonth() + delta);
        renderCalendar(currentDate);
    }

    prevButton.addEventListener('click', () => changeMonth(-1));
    nextButton.addEventListener('click', () => changeMonth(1));

    renderCalendar(currentDate);
});

document.getElementById('editBtn').addEventListener('click', function() {
    let inputs = document.querySelectorAll('.profile-right input, .profile-right textarea');
    inputs.forEach(input => input.disabled = false);
    
    document.getElementById('editBtn').style.display = 'none';
    document.getElementById('saveBtn').style.display = 'block';
});

document.getElementById('saveBtn').addEventListener('click', function() {
    let inputs = document.querySelectorAll('.profile-right input, .profile-right textarea');
    inputs.forEach(input => input.disabled = true);
    
    document.getElementById('editBtn').style.display = 'block';
    document.getElementById('saveBtn').style.display = 'none';
});

document.getElementById('imageUpload').addEventListener('change', function(event) {
    const [file] = event.target.files;
    if (file) {
        document.getElementById('profileImage').src = URL.createObjectURL(file);
    }
});

