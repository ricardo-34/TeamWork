<?php
session_start();
include('PHP/conexion.php'); // Incluye la conexión a la base de datos

// Verifica si el código fue enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codigoIngresado = $_POST['codigo'];
    $nuevaPassword = $_POST['password'];
    $confirmarPassword = $_POST['confirm_password'];
    
    // Verifica si el código coincide con el que está en la sesión
    if ($codigoIngresado == $_SESSION['codigo']) {
        // Verifica si las contraseñas coinciden
        if ($nuevaPassword == $confirmarPassword) {
            $email = $_SESSION['email'];
            
            // Encripta la nueva contraseña antes de guardarla
            $hashedPassword = password_hash($nuevaPassword, PASSWORD_DEFAULT);
            
            // Actualiza la contraseña en la base de datos
            $sql = "UPDATE usuarios SET password='$hashedPassword' WHERE email='$email'";
            
            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('Contraseña actualizada correctamente.'); window.location.href = 'index.php';</script>";
            } else {
                echo "Error al actualizar la contraseña: " . $conn->error;
            }
        } else {
            echo "Las contraseñas no coinciden.";
        }
    } else {
        echo "El código ingresado es incorrecto.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar Contraseña</title>
    <link rel="stylesheet" href="CSS/recupera-contrasena.css">
</head>
<body>
    <div class="container">
        <h2>Cambiar Contraseña</h2>
        <form method="POST" action="">
            <label for="codigo">Código de Recuperación:</label><br>
            <input type="text" id="codigo" name="codigo" required><br><br>

            <label for="password">Nueva Contraseña:</label><br>
            <input type="password" id="password" name="password" required><br><br>

            <label for="confirm_password">Confirmar Nueva Contraseña:</label><br>
            <input type="password" id="confirm_password" name="confirm_password" required><br><br>

            <button type="submit">Cambiar Contraseña</button>
        </form>
    </div>
</body>
</html>

