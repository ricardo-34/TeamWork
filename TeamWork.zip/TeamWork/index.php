<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TeamWork</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
    <meta name="google-signin-client_id"
        content="69038096642-dc40v3gg354igo9l9j2a5er9np97mqm0.apps.googleusercontent.com">
    <script src="https://accounts.google.com/gsi/client" async defer></script>


</head>

<body>

    <header>
        <div class="container__header">
            <div class="logo">
                <a href="#">
                    <img src="IMG/Logo.png" alt="" />
                </a>
            </div>

            <div class="menu">
                <nav>
                    <ul>
                        <li><a href="#container_bienvenida">Inicio</a></li>
                        <li><a href="#container_informacion">Servicios</a></li>

                        <li><a href="#container_acerca">Acerca de</a></li>
                    </ul>
                </nav>

                <a href="#" class="action-button" id="loginBtn">Registrase</a>
            </div>
        </div>
    </header>

    <main>

        <div class="modal-overlay ocultar-modal"></div>

        <div class="modal-overlay ocultar-modal"></div>

        <!-- Modal de Inicio de sesión -->

        <div class="modal-initiates" id="modal-login">
            <div class="modal-content-login">
                <span class="modal-close-login">&times;</span>
                <h2 class="modal-title-login">Hola!!</h2>
                <p class="modal-subtitle-login">Inicia sesión en tu cuenta</p>

                <form action="php/login_usuario_be.php" method="post" class="form-login" id="login-form">
                    <div class="form-group-login">
                        <h3 class="txt-registro">Usuario</h3>
                        <input type="text" id="login-username" name="username_email_login"
                            placeholder="Introduzca su usuario" required>
                    </div>
                    <div class="form-group-login">
                        <h3 class="txt-registro">Contraseña</h3>
                        <input type="password" id="login-password" name="password_login"
                            placeholder="Introduzca su contraseña" required>
                    </div>
                    <div class="link-container">
                        <a class="link-create-account" href="#">Crear cuenta</a>
                        <a class="link-forgot-password" href="#">Olvidaste tu contraseña</a>
                    </div>
                    <button type="submit" class="submit-button-login">Iniciar sesión</button>
                    <div class="divider-login">
                        <hr>
                        <span>o</span>
                        <hr>
                    </div>
                    <div>

                        <a href="https://accounts.google.com/o/oauth2/auth?client_id=69038096642-dc40v3gg354igo9l9j2a5er9np97mqm0.apps.googleusercontent.com&redirect_uri=http://localhost/TeamWork/callback.php&response_type=code&scope=email profile"
                            class="social-button-login" id="google-login">
                            <button type="button">
                                <img src="IMG/google.png" alt="Google" width="20" height="20"> Continuar con Google
                            </button>

                        </a>

                    </div>
                </form>
            </div>
        </div>

        <!-- Modal de Registro -->
        <div class="modal-initiates" id="modal-register">
            <div class="modal-content-register">
                <span class="modal-close-register">&times;</span>
                <span class="modal-back-register">&#8592;</span>
                <h2 class="modal-title-register">Crear cuenta</h2>
                <form action="php/registro_usuario_be.php" method="post" class="form-register">

                    <div class="form-group-register">
                        <h3 class="txt-registro">Nombre</h3>
                        <input type="text" id="register-nombre" name="nombre_registre"
                            placeholder="Introduzca su nombre" required>
                    </div>
                    <div class="form-group-register">
                        <h3 class="txt-registro">Usuario</h3>
                        <input type="text" id="register-username" name="username_registre"
                            placeholder="Introduzca su usuario" required>
                    </div>
                    <div class="form-group-register">
                        <h3 class="txt-registro">Correo</h3>
                        <input type="email" id="register-email" name="email_registre" placeholder="Introduzca su correo"
                            required>
                    </div>

                    <div class="form-group-register">
                        <h3 class="txt-registro">Cotraseña</h3>
                        <div class="password-level">
                            <span class="password-leves">

                            </span><span class="password-leves">

                            </span><span class="password-leves"></span>
                        </div>
                        <input type="password" id="register-password" name="password_registre"
                            placeholder="Introduzca su contraseña" required>
                        <img class="eye eye-show" id src="IMG/mostrar.png" alt="">
                        <img class="eye eye-close show" src="IMG/no mostrar.png" alt="">
                    </div>
                    <div class="form-group-register">
                        <h3 class="txt-registro">Confirmar contraseña</h3>
                        <input type="password" id="register-confirm-password" name="confirm_password_registre"
                            placeholder="Vuelva a introducir su contraseña" required>
                        <span id="msg-error"></span>
                    </div>
                    <button type="submit" class="submit-button-register">Crear cuenta</button>
                    <div class="divider-login">
                        <hr>
                        <span>o</span>
                        <hr>
                    </div>
                    <button type="button" class="social-button-login"><img src="IMG/google.png" alt="Google" width="20"
                            height="20"> Continuar con Google</button>
                </form>
            </div>
        </div>

        <!-- Modal de olvido contraseña -->
        <div class="modal-initiates" id="modal-olvido-contraseña">
            <div class="modal-content-olvido-contraseña">
                <span class="modal-close-olvido-contraseña">&times;</span>
                <h1 class="modal-title-olvido-contraseña">Recupera la contraseña</h1>
                <p class="modal-subtitle-olvido-contraseña">Proporcina tu correo con el que registraste tu cuenta, luego
                    te enviaremos un correo para que puedas cambiar tu contrasena.
                </p>

                <form method="POST" action="PHP/recuperar_contrasena.php">
                    <label for="email">Correo electrónico:</label>
                    <input type="email" id="email" name="email" required>
                    <button type="submit">Enviar código</button>
                </form>


            </div>
        </div>

        <div class="container_bienvenida" id="container_bienvenida">

            <div class="cont_bienv_contenido">

                <div class="cont_bienv_text">
                    <div>
                        <h1>Bienvenido a</h1>
                        <h2>TeamWork: solución integral para la creación de proyectos</h2>
                        <p>
                            Tu herramienta esencial para la colaboración en proyectos grupales. Organiza, comunica y
                            colabora con facilidad.
                        </p>
                    </div>
                    <div class="div_btn_demostracion">
                        <a href="#" class="show-video-btn">Ver Demostración</a>

                        <div class="modal-overlay-wrapper">
                            <div class="modal-background hidden-element"></div>
                            <div class="video-modal hidden-element">
                                <span class="modal-close-btn">&times;</span>
                                <div class="video-container">
                                    <video controls>
                                        <source src="video.mp4" type="video/mp4">
                                        Tu navegador no soporta el elemento de video.
                                    </video>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="cont_bienv_img">
                    <img src="IMG/binevenida.png" alt="">
                </div>

            </div>





        </div>

        <div class="container_informacion" id="container_informacion">

            <div class="conta_infor">

                <div class="conta_infor_text">
                    <h1>Transforma la Gestión de tus Proyectos con TeamWork</h1>

                    <p>Bienvenido a TeamWork, la plataforma definitiva para gestionar proyectos en equipo. Con nuestras
                        herramientas avanzadas, puedes optimizar cada fase del proyecto, colaborar eficientemente con tu
                        equipo y alcanzar tus objetivos con éxito. ¡Descubre cómo TeamWork puede llevar tus proyectos al
                        siguiente nivel!</p>
                </div>

                <div class="conta_infor_cuadros">

                    <div class="conta_infor_cuadro">

                        <div class="conta_infor_cuadro_img">
                            <img src="IMG/Organiza y Monitorea.png" alt="">

                        </div>

                        <div class="conta_infor_cuadro_txt">
                            <h4>Organiza y Monitorea</h4>
                            <p>Asigna tareas, monitorea el progreso y centraliza la documentación en un solo lugar.

                            </p>

                        </div>

                    </div>

                    <div class="conta_infor_cuadro">

                        <div class="conta_infor_cuadro_img">
                            <img src="IMG/Comunicación Eficiente.png" alt="">
                        </div>

                        <div class="conta_infor_cuadro_txt">
                            <h4>Comunicación Eficiente</h4>
                            <p>Chat en vivo, foros de discusión y notificaciones en tiempo real para mantener a tu
                                equipo siempre conectado.</p>
                        </div>
                    </div>

                    <div class="conta_infor_cuadro">

                        <div class="conta_infor_cuadro_img">
                            <img src="IMG/Calendario Interactivo.png" alt="">
                        </div>

                        <div class="conta_infor_cuadro_txt">
                            <h4>Calendario Interactivo</h4>
                            <p>Visualiza plazos, asigna recursos y recibe recordatorios para mantener tu proyecto en
                                curso.
                            </p>

                        </div>
                    </div>

                </div>

            </div>

        </div>

        <div class="container_beneficios" id="container_beneficios">

            <div class="conta_cuadros">

                <div class="conta_cuadro_uno">

                    <div class="info-box-minimal">
                        <h2>Beneficios de TeamWork</h2>
                        <p>TeamWork está diseñado para ofrecer una solución completa en la gestión de proyectos. Aquí te
                            mostramos cómo puede transformar tu flujo de trabajo:</p>

                        <div class="scrolling-container">

                            <div class="scrolling-content">
                                <div class="benefit-item">
                                    <h3>Gestión Eficiente de Tareas</h3>
                                    <p>Asigna, prioriza y realiza un seguimiento de las tareas de manera sencilla y
                                        efectiva.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Comunicación Fluida</h3>
                                    <p>Facilita la comunicación entre los miembros del equipo con herramientas
                                        integradas de chat y notificaciones.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Vistas Flexibles</h3>
                                    <p>Utiliza vistas de tableros Kanban y diagramas de Gantt para una visualización
                                        clara y detallada del progreso.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Integraciones Potentes</h3>
                                    <p>Conecta con aplicaciones como Slack, Google Drive y Trello para una gestión
                                        integrada y sin fisuras.</p>
                                </div>


                                <div class="benefit-item">
                                    <h3>Gestión Eficiente de Tareas</h3>
                                    <p>Asigna, prioriza y realiza un seguimiento de las tareas de manera sencilla y
                                        efectiva.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Comunicación Fluida</h3>
                                    <p>Facilita la comunicación entre los miembros del equipo con herramientas
                                        integradas de chat y notificaciones.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Vistas Flexibles</h3>
                                    <p>Utiliza vistas de tableros Kanban y diagramas de Gantt para una visualización
                                        clara y detallada del progreso.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Integraciones Potentes</h3>
                                    <p>Conecta con aplicaciones como Slack, Google Drive y Trello para una gestión
                                        integrada y sin fisuras.</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

                <div class="conta_cuadro_dos">

                    <div class="info-box-minimal">
                        <h2>Beneficios de TeamWork</h2>
                        <p>TeamWork está diseñado para ofrecer una solución completa en la gestión de proyectos. Aquí te
                            mostramos cómo puede transformar tu flujo de trabajo:</p>

                        <div class="scrolling-container">

                            <div class="scrolling-contentr">
                                <div class="benefit-item">
                                    <h3>Gestión Eficiente de Tareas</h3>
                                    <p>Asigna, prioriza y realiza un seguimiento de las tareas de manera sencilla y
                                        efectiva.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Comunicación Fluida</h3>
                                    <p>Facilita la comunicación entre los miembros del equipo con herramientas
                                        integradas de chat y notificaciones.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Vistas Flexibles</h3>
                                    <p>Utiliza vistas de tableros Kanban y diagramas de Gantt para una visualización
                                        clara y detallada del progreso.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Integraciones Potentes</h3>
                                    <p>Conecta con aplicaciones como Slack, Google Drive y Trello para una gestión
                                        integrada y sin fisuras.</p>
                                </div>


                                <div class="benefit-item">
                                    <h3>Gestión Eficiente de Tareas</h3>
                                    <p>Asigna, prioriza y realiza un seguimiento de las tareas de manera sencilla y
                                        efectiva.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Comunicación Fluida</h3>
                                    <p>Facilita la comunicación entre los miembros del equipo con herramientas
                                        integradas de chat y notificaciones.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Vistas Flexibles</h3>
                                    <p>Utiliza vistas de tableros Kanban y diagramas de Gantt para una visualización
                                        clara y detallada del progreso.</p>
                                </div>
                                <div class="benefit-item">
                                    <h3>Integraciones Potentes</h3>
                                    <p>Conecta con aplicaciones como Slack, Google Drive y Trello para una gestión
                                        integrada y sin fisuras.</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

            </div>

            <div class="conta_rectangulo">

                <div class="conta_rectangulo_uno">

                    <div class="feature-summary">
                        <h2>Gestión de Proyectos Simplificada</h2>

                        <p>Con TeamWork, puedes crear tareas, establecer plazos y prioridades, y monitorear el avance en
                            tiempo real. Nuestro sistema de notificaciones asegura que nunca te pierdas una
                            actualización importante, mientras que las vistas de calendario y tablero proporcionan una
                            visión clara del estado de tus proyectos.</p>
                        <p>Además, nuestras integraciones con herramientas populares como Slack y Google Drive facilitan
                            la colaboración y la gestión de documentos, permitiendo a tu equipo trabajar juntos sin
                            esfuerzo y con mayor eficacia.</p>
                    </div>

                </div>

                <div class="conta_rectangulo_uno">

                    <div class="feature-summary">
                        <h2>Optimización de Flujos de Trabajo</h2>
                        <p>Maximiza la eficiencia de tu equipo con nuestras herramientas avanzadas para la gestión de
                            proyectos. TeamWork te permite automatizar tareas repetitivas, configurar recordatorios y
                            coordinar actividades con facilidad.</p>
                        <p>Nuestra plataforma ofrece una variedad de vistas para tus proyectos, incluyendo tableros
                            Kanban y diagramas de Gantt, lo que facilita la planificación y el seguimiento del progreso.
                            Además, la integración con aplicaciones de productividad como Trello y Asana garantiza una
                            transición fluida entre tus herramientas favoritas.</p>
                    </div>

                </div>

            </div>

        </div>

        <div class="container_acerca" id="container_acerca">

            <div class="cont_acerca_contenido">

                <div class="cont_acerca_text">
                    <div>
                        <h1>Acerca de</h1>
                        <p>
                            En TeamWork, creemos que el éxito de cualquier proyecto radica en la colaboración efectiva y
                            la comunicación clara. Nuestra plataforma ha sido diseñada para simplificar y optimizar la
                            gestión de proyectos grupales, proporcionando a los equipos las herramientas necesarias para
                            organizar tareas, compartir ideas y seguir el progreso de forma intuitiva. Con una interfaz
                            amigable y funcionalidades robustas, TeamWork facilita la coordinación y asegura que todos
                            los miembros del equipo estén alineados y trabajando hacia un objetivo común.
                        </p>

                        <p>
                            Desde estudiantes hasta profesionales, TeamWork es la elección perfecta para cualquier grupo
                            que busque mejorar su productividad y cohesión. Nos esforzamos por crear un entorno donde la
                            colaboración fluya sin fricciones, permitiendo a los equipos centrarse en lo que realmente
                            importa: lograr resultados. Ya sea que estés gestionando un proyecto escolar, un plan de
                            negocios, o una iniciativa comunitaria, TeamWork está aquí para ayudarte a alcanzar tus
                            metas con éxito y eficiencia.
                        </p>

                    </div>

                </div>

                <div class="cont_acerca_img">
                    <img src="IMG/about.png" alt="">
                </div>

            </div>

        </div>


    </main>

    <footer>

        <div class="contenedor_footer">

            <div class="conte">
                <div class="conten_imagenes">
                    <a href="https://www.facebook.com" target="_blank">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://www.instagram.com" target="_blank">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://www.youtube.com" target="_blank">
                        <i class="fab fa-youtube"></i>
                    </a>
                    <a href="https://www.twitter.com" target="_blank">
                        <i class="fab fa-twitter"></i>
                    </a>
                    </a>
                </div>

                <div class="conten_logo">
                    <img src="IMG/Logo.png" alt="">
                </div>

                <div class="conten_copir">
                    <p> copyright &copy; 2024 TeamWork</p>
                </div>

                <!--<div class="conten_infor">
                    <a href="informacion legal.html">Infomación legal</a>
                    <p>|</p>
                    <a href="politica.html">Politica de privacidad</a>
                </div>-->
            </div>

        </div>

    </footer>

    <script src="JS/script.js"></script>

</body>

</html>