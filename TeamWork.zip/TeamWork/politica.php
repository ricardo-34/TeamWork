<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad - TeamWord</title>
    <link rel="stylesheet" href="CSS/politica.css">
</head>
<body>

    <header>
        <h1>Política de Privacidad</h1>
        <p>Fecha de entrada en vigor: <strong>[Fecha]</strong></p>
    </header>

    <section>
        <h2>1. Información que recopilamos</h2>
        <p>Recopilamos varios tipos de información para ofrecer una mejor experiencia y optimizar nuestros servicios:</p>
        <ul>
            <li><strong>Información proporcionada por el usuario:</strong> Nombre, correo electrónico, imagen de perfil, y otros datos que decides añadir al registrarte.</li>
            <li><strong>Información de uso:</strong> Detalles de la interacción con la plataforma, como creación de proyectos, comentarios, dirección IP, tipo de dispositivo, y datos de navegación.</li>
            <li><strong>Archivos y contenidos compartidos:</strong> Archivos y documentos subidos en los proyectos.</li>
        </ul>
    </section>

    <section>
        <h2>2. Cómo utilizamos la información</h2>
        <p>Utilizamos los datos que recopilamos para:</p>
        <ul>
            <li>Facilitar la creación y gestión de proyectos grupales.</li>
            <li>Personalizar tu experiencia en la plataforma.</li>
            <li>Mejorar la funcionalidad y seguridad de TeamWord.</li>
            <li>Enviar notificaciones relacionadas con proyectos, tareas y actualizaciones.</li>
        </ul>
    </section>

    <section>
        <h2>3. Compartición de datos</h2>
        <p>No compartimos tu información personal con terceros, excepto en las siguientes circunstancias:</p>
        <ul>
            <li><strong>Proveedores de servicios:</strong> Utilizamos terceros para servicios de alojamiento, análisis y mantenimiento de la plataforma.</li>
            <li><strong>Requerimientos legales:</strong> Compartimos información si lo exige la ley o una orden judicial.</li>
        </ul>
    </section>

    <section>
        <h2>4. Protección de la información</h2>
        <p>Implementamos medidas de seguridad físicas, técnicas y administrativas para proteger tus datos de accesos no autorizados, alteraciones, divulgación o destrucción.</p>
    </section>

    <section>
        <h2>5. Derechos del usuario</h2>
        <p>Tienes el derecho a:</p>
        <ul>
            <li>Acceder, actualizar o corregir tu información personal.</li>
            <li>Solicitar la eliminación de tu cuenta y datos asociados.</li>
            <li>Oponerte al procesamiento de tu información personal en ciertas circunstancias.</li>
        </ul>
    </section>

    <section>
        <h2>6. Retención de datos</h2>
        <p>Mantenemos tu información personal mientras sea necesario para cumplir con los fines descritos en esta política, a menos que se requiera un período de retención más largo por ley.</p>
    </section>

    <section>
        <h2>7. Uso de cookies</h2>
        <p>Utilizamos cookies y tecnologías similares para mejorar tu experiencia en TeamWord, como recordar tu inicio de sesión y analizar patrones de uso de la plataforma. Puedes controlar el uso de cookies en la configuración de tu navegador.</p>
    </section>

    <section>
        <h2>8. Privacidad de menores</h2>
        <p>TeamWord no está destinado a menores de 13 años. No recopilamos conscientemente información personal de menores de edad. Si detectamos que hemos recopilado información de un menor sin el consentimiento adecuado, eliminaremos dicha información.</p>
    </section>

    <section>
        <h2>9. Seguridad de la información</h2>
        <p>Hemos implementado políticas internas y utilizamos herramientas de seguridad como el cifrado de datos y controles de acceso para garantizar la protección de tu información personal en nuestros sistemas.</p>
    </section>

    <section>
        <h2>10. Cambios en la política de privacidad</h2>
        <p>Podemos actualizar esta política en cualquier momento para reflejar cambios en nuestros servicios o en las leyes aplicables. Te informaremos mediante la plataforma o por correo electrónico antes de que cualquier cambio sea efectivo.</p>
    </section>

    <section>
        <h2>11. Contacto</h2>
        <p>Si tienes alguna duda sobre esta política de privacidad o sobre cómo manejamos tu información personal, no dudes en contactarnos:</p>
        <p><strong>Correo electrónico:</strong> contacto@teamword.com</p>
        <p><strong>Teléfono:</strong> +123 456 7890</p>
    </section>

    <footer>
        <p>&copy; 2024 TeamWord. Todos los derechos reservados.</p>
    </footer>

</body>
</html>
