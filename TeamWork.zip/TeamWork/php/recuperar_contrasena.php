<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Incluir las clases de PHPMailer
require '../vendor/autoload.php'; // Asegúrate de que la ruta sea correcta

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    include('conexion.php');

    $sql = "SELECT * FROM usuarios WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $codigo = rand(100000, 999999);
        $_SESSION['codigo'] = $codigo;
        $_SESSION['email'] = $email;

        // Configuración de PHPMailer
        $mail = new PHPMailer(true);
        try {
            // Servidor SMTP de Gmail
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'recovery.teamwork.01@gmail.com'; // Usa aquí una contraseña de aplicación en lugar de la contraseña normal
            $mail->Password = 'a e q d d a v i n s k f b c s x'; // Cambia esto por una contraseña de aplicación
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Destinatarios
            $mail->setFrom('recovery.teamwork.01@gmail.com', 'TeamWork Soporte'); // Usa un nombre formal
            $mail->addAddress($email);

            // Contenido del correo
            $mail->isHTML(true);
            $mail->Subject = 'Recuperacion de contraseña - TeamWork';
            $mail->Body = "
                <p>Estimado usuario,</p>
                <p>Recibimos una solicitud para restablecer tu contraseña. Si no has realizado esta solicitud, puedes ignorar este correo.</p>
                <p>Tu código de recuperación es: <b>$codigo</b></p>
                <p>Para cambiar tu contraseña, haz clic en el siguiente enlace:</p>
                <a href='http://localhost/TeamWork/cambiar_contrasena.php'>Cambiar Contraseña</a>
                <p>Gracias por utilizar TeamWork.</p>
            ";

            $mail->send();
            echo "<script>alert('Código enviado correctamente. Revisa tu correo.'); window.location.href = '../index.php';</script>";
        } catch (Exception $e) {
            echo "Error al enviar el correo: {$mail->ErrorInfo}";
        }
    } else {
        echo "El correo electrónico no está registrado.";
    }

    $conn->close();
}
?>
