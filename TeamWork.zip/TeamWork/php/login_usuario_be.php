<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir datos del formulario de inicio de sesión
    $usuario_email = mysqli_real_escape_string($conn, $_POST['username_email_login']);
    $password = mysqli_real_escape_string($conn, $_POST['password_login']);

    // Comprobar si el usuario existe
    $sql = "SELECT * FROM usuarios WHERE username='$usuario_email' OR email='$usuario_email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Verificar la contraseña
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Iniciar sesión
            session_start();
            session_regenerate_id(true);
            $_SESSION['usuario'] = $row['username'];
            echo "<script> window.location.href = '../index-user.php';</script>";
        } else {
            echo "<script>alert('Contraseña incorrecta'); window.location.href = '../index.php';</script>";
        }
    } else {
        echo "<script>alert('Usuario o correo no encontrado'); window.location.href = '../index.php';</script>";
    }

    // Cerrar la conexión
    $conn->close();
}
?>
