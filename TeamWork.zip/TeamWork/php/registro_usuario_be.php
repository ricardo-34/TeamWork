<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir datos del formulario de registro
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre_registre']);
    $usuario = mysqli_real_escape_string($conn, $_POST['username_registre']);
    $email = mysqli_real_escape_string($conn, $_POST['email_registre']);
    $password = mysqli_real_escape_string($conn, $_POST['password_registre']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password_registre']);

    // Verificar si las contraseñas coinciden
    if ($password !== $confirm_password) {
        echo "<script>alert('Las contraseñas no coinciden'); window.location.href = '../index.php';</script>";
        exit();
    }

    // Encriptar la contraseña
    $password_encriptada = password_hash($password, PASSWORD_BCRYPT);

    // Comprobar si el usuario ya existe
    $sql = "SELECT * FROM usuarios WHERE username='$usuario' OR email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<script>alert('El nombre de usuario o el correo ya están en uso'); window.location.href = '../index.php';</script>";
    } else {
        // Insertar el nuevo usuario en la base de datos
        $sql = "INSERT INTO usuarios (nombre, username, email, password) VALUES ('$nombre', '$usuario', '$email', '$password_encriptada')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Registro exitoso. Puedes iniciar sesión.'); window.location.href = '../index.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Cerrar la conexión
    $conn->close();
}
?>
